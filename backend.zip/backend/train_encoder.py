import argparse
import json
import os
import pickle
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

from tokenizer import SimpleTokenizer
from model import TransformerEncoderModel


class TripletTextDataset(Dataset):
    def __init__(self, triplets, tokenizer):
        self.triplets = triplets
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.triplets)

    def __getitem__(self, idx):
        row = self.triplets[idx]
        return (
            self.tokenizer.encode(row["anchor"]),
            self.tokenizer.encode(row["positive"]),
            self.tokenizer.encode(row["negative"]),
        )


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def evaluate_retrieval(model, tokenizer, triplets, device):
    model.eval()
    correct = 0
    distances = []
    with torch.no_grad():
        for row in triplets:
            a = tokenizer.encode(row["anchor"]).unsqueeze(0).to(device)
            p = tokenizer.encode(row["positive"]).unsqueeze(0).to(device)
            n = tokenizer.encode(row["negative"]).unsqueeze(0).to(device)
            ae, pe, ne = model(a), model(p), model(n)
            pos_sim = torch.cosine_similarity(ae, pe).item()
            neg_sim = torch.cosine_similarity(ae, ne).item()
            correct += int(pos_sim > neg_sim)
            distances.append(pos_sim - neg_sim)
    return {
        "pairwise_accuracy": round(correct / max(1, len(triplets)), 4),
        "avg_similarity_margin": round(float(np.mean(distances)), 4),
    }


def main():
    parser = argparse.ArgumentParser(description="Train custom Transformer encoder for StudyMate AI retrieval")
    parser.add_argument("--data", default="data/training_triplets.json")
    parser.add_argument("--epochs", type=int, default=18)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--max-len", type=int, default=96)
    parser.add_argument("--out", default="artifacts")
    args = parser.parse_args()

    set_seed(42)
    out_dir = Path(args.out)
    out_dir.mkdir(exist_ok=True)

    with open(args.data, "r", encoding="utf-8") as f:
        triplets = json.load(f)

    random.shuffle(triplets)
    split = int(0.85 * len(triplets))
    train_rows = triplets[:split]
    val_rows = triplets[split:]

    all_texts = []
    for row in train_rows:
        all_texts.extend([row["anchor"], row["positive"], row["negative"]])

    tokenizer = SimpleTokenizer(min_freq=1, max_vocab_size=30000, max_len=args.max_len)
    tokenizer.build_vocab(all_texts)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TransformerEncoderModel(vocab_size=len(tokenizer.word2idx), max_len=args.max_len).to(device)

    train_loader = DataLoader(TripletTextDataset(train_rows, tokenizer), batch_size=args.batch_size, shuffle=True)
    criterion = nn.TripletMarginLoss(margin=0.35)
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)

    best_acc = -1
    history = []
    print(f"Training samples: {len(train_rows)} | Validation samples: {len(val_rows)} | Vocab: {len(tokenizer.word2idx)} | Device: {device}")

    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss = 0.0
        for anchor, positive, negative in train_loader:
            anchor, positive, negative = anchor.to(device), positive.to(device), negative.to(device)
            anchor_emb = model(anchor)
            positive_emb = model(positive)
            negative_emb = model(negative)
            loss = criterion(anchor_emb, positive_emb, negative_emb)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total_loss += loss.item()

        metrics = evaluate_retrieval(model, tokenizer, val_rows, device)
        avg_loss = total_loss / max(1, len(train_loader))
        history.append({"epoch": epoch, "loss": round(avg_loss, 4), **metrics})
        print(f"Epoch {epoch:02d}/{args.epochs} | loss={avg_loss:.4f} | val_acc={metrics['pairwise_accuracy']:.4f} | margin={metrics['avg_similarity_margin']:.4f}")

        if metrics["pairwise_accuracy"] > best_acc:
            best_acc = metrics["pairwise_accuracy"]
            torch.save(model.state_dict(), out_dir / "encoder_model.pth")
            with open(out_dir / "tokenizer.pkl", "wb") as f:
                pickle.dump(tokenizer, f)

    with open(out_dir / "training_history.json", "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2)

    print("\nSaved best model to artifacts/encoder_model.pth")
    print("Saved tokenizer to artifacts/tokenizer.pkl")
    print("Saved training history to artifacts/training_history.json")


if __name__ == "__main__":
    main()
